import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DataStateChangeEvent, GridComponent } from '@progress/kendo-angular-grid';
import { getCarStockConfig } from '../core/data/car-stock.config';
import { DataProviderCarStock } from '../core/data/car-stock.model';
import { ProgressServiceFactory } from '../core/data/progress-service-factory';

const createFormGroup: (item: any) => FormGroup = (dataItem: any) =>
  new FormGroup({
    CarStockId: new FormControl(dataItem.CarStockId),
    CarId: new FormControl(dataItem.CarId),
    ValidFrom: new FormControl(dataItem.ValidFrom),
    ValidTo: new FormControl(dataItem.ValidTo),
    StockAmount: new FormControl(dataItem.StockAmount),
  });

  
@Component({
  selector: 'app-car-stock-view',
  templateUrl: './car-stock-view.component.html',
  styleUrls: ['./car-stock-view.component.css']
})
export class CarStockViewComponent implements OnChanges {

  @Input() 
  CarId: string = "";

  public state: any = {
    skip: 0,
    take: 10,
    filter: {
      logic: 'and',
      filters: [],
   },
  };

  public dataService;
  public dataServiceData: any;
  public view;
  public editDataModel: any;
  private editedRowIndex: number;
  private originalItem: any;
  public formGroup: FormGroup;

  constructor (private progressServiceFactory: ProgressServiceFactory) {
    this.dataService =
    this.progressServiceFactory.getService<DataProviderCarStock>(
      getCarStockConfig(),
      this.state
    );

    this.view = this.dataService.dataChanges();
  }

 public ngOnInit(): void {
    this.dataServiceData = this.dataService.dataChanges();
    this.dataService.dataChanges().subscribe((data) => {
    });
    if(this.CarId != ""){
      this.state.filter.filters = [{field: "CarId", operator: "eq", value: this.CarId}];
    }
   
    this.dataService.read(this.state);
  }

  public ngOnChanges(): void {
    if(this.CarId != ""){
      this.state.filter.filters = [{field: "CarId", operator: "eq", value: this.CarId}];
    }
    this.dataService.read(this.state);
  }
  
  public editHandler(e: any): void {
    const { sender, rowIndex, dataItem } = e;
    this.originalItem = Object.assign({}, dataItem);
    this.editDataModel = dataItem;
    this.formGroup = createFormGroup(this.originalItem);
    this.closeEditor(sender);
    this.editedRowIndex = rowIndex;
    sender.editRow(rowIndex, this.formGroup);
  }
  
  public cancelHandler({ sender, rowIndex }: any): void {
    Object.assign(this.editDataModel, this.originalItem);
    this.closeEditor(sender, rowIndex);
  }
  
  public saveHandler({ sender, rowIndex, isNew }: any): void {
    const item: any = Object.assign(this.editDataModel, this.formGroup.value);
    item.CustNum = this.CarId;
    if (isNew) {
      this.dataService.create(item);
    } else {
      this.dataService.update(item);
    }
  
    sender.closeRow(rowIndex);
  }
  
  public addHandler(e: any): void {
    const { sender } = e;
    this.editDataModel = this.dataService.createModel();
    this.formGroup = createFormGroup({});
    this.closeEditor(sender);
    sender.addRow(this.formGroup);
  }
  
  public removeHandler(e: any): void {
    const { dataItem } = e;
    this.dataService.remove(dataItem);
  }
  
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.dataService.read(this.state);
  }
  
  private closeEditor(
    grid: GridComponent,
    rowIndex: number = this.editedRowIndex
  ): void {
    grid.closeRow(rowIndex);
    this.editedRowIndex = undefined;
  }
 
}
