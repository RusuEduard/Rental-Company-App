import { Component, OnInit } from '@angular/core';
import { getCarTypeConfig } from '../core/data/car-type.config';
import { DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { DataProviderCarType } from '../core/data/car-type.model';
import { getCarConfig } from '../core/data/car.config';
import { DataProviderCar } from '../core/data/car.model';
import { ProgressServiceFactory } from '../core/data/progress-service-factory';

@Component({
  selector: 'app-car-view',
  templateUrl: './car-view.component.html',
  styleUrls: ['./car-view.component.css']
})
export class CarViewComponent implements OnInit {

  public currentCar: string = "";

  public state: any = {
    skip: 0,
    take: 10,
    filter: {
      logic: 'and',
      filters: [],
    },
  };

  public state2: any = {
    skip: 0,
    take: 100,
  };

  public editDataItem: DataProviderCar;
  public isNew: boolean;
  public CarTypesList: Array<DataProviderCarType> = [];
  public dataService;
  public stateDataService;
  public dataServiceData: any;
  public view;
  public editDataModel: any;

  constructor(private progressServiceFactory: ProgressServiceFactory) {
    this.dataService =
      this.progressServiceFactory.getService<DataProviderCar>(
        getCarConfig(),
        this.state
      );

    this.view = this.dataService.dataChanges();

    this.stateDataService =
      this.progressServiceFactory.getService<DataProviderCarType>(
        getCarTypeConfig(),
        this.state2
      );
  }

  public ngOnInit(): void {
    console.log(this.dataService);
    this.dataServiceData = this.dataService.dataChanges();

    this.dataService.dataChanges().subscribe((data) => console.log(data));

    this.stateDataService.dataChanges().subscribe((data) => {
      if (data && data['data']) this.CarTypesList = data['data'];
    });
    this.dataService.read();
    this.stateDataService.read();
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.dataService.read(this.state);
  }

  public addHandler() {
    this.editDataItem = new DataProviderCar();
    this.isNew = true;
  }

  public editHandler({ dataItem }) {
    this.editDataItem = dataItem;
    this.isNew = false;
  }

  public cancelHandler() {
    this.editDataItem = undefined;
  }

  public saveHandler(car) {
    if (this.isNew) {
      this.dataService.create(car);
    } else {
      this.dataService.update(car);
    }

    this.editDataItem = undefined;
  }

  public removeHandler({ dataItem }) {
    this.dataService.remove(dataItem);
  }

  gridUserSelectionChange(carGrid, selection) {
    const selectedData = selection.selectedRows[0].dataItem;
    this.currentCar = selectedData.CarId;
    console.log("cristina",this.currentCar);
  }

  public cartypes(id: string): any {
    
    const t = this.CarTypesList.find((x) => x.CarTypeId === id);
    
    return t;
  }

}


