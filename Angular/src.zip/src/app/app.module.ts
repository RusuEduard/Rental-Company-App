import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CarViewComponent } from './car-view/car-view.component';
import { ProgressServiceFactory } from './core/data/progress-service-factory';
import { ProgressSessionService } from './core/data/progress-session.service';
import { DataProviderService } from './core/data/service-config';
import { DropDownListFilterComponent } from './dropdownlist-filter/dropdownlist-filter.component';
import { EditFormComponent } from './edit-form/edit-form.component';
import { CarStockViewComponent } from './car-stock-view/car-stock-view.component';
import { AppUserViewComponent } from './app-user-view/app-user-view.component';
import { EditFormAppuserComponent } from './edit-form-appuser/edit-form-appuser.component';
import { RoleTypeViewComponent } from './role-type-view/role-type-view.component';
import { RentViewComponent } from './rent-view/rent-view.component';
import { RentCarViewComponent } from './rent-car-view/rent-car-view.component';
import { EditFormRentComponent } from './edit-form-rent/edit-form-rent.component';

@NgModule({
  declarations: [
    AppComponent,
    CarViewComponent,
    DropDownListFilterComponent,
    EditFormComponent,
    CarStockViewComponent,
    AppUserViewComponent,
    EditFormAppuserComponent,
    RoleTypeViewComponent,
    RentViewComponent,
    RentCarViewComponent,
    EditFormRentComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,

    AppRoutingModule,
    GridModule,
    ReactiveFormsModule,
    DropDownListModule,
    InputsModule,
    DialogModule,
    LabelModule,
    BrowserAnimationsModule,
    GridModule
    
  ],
  providers: [ DataProviderService,
    ProgressServiceFactory,
    ProgressSessionService,
    HttpClient,
    ],
    
  bootstrap: [AppComponent]
})
export class AppModule { }
