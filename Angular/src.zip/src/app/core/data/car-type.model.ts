export class DataProviderCarType{
    public CarTypeId: string;          
    public DESCRIPTION: string;    
    public seq: number;          

}