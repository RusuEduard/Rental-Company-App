export class DataProviderCar {
    public CarId: string;
    public CarTypeId: string;
    public Manufacturer: string;
    public Model: string;
    public id: string;
    public seq: number;
}

