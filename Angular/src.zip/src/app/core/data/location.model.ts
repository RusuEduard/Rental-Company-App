export class SmartProviderLocation {
    public HasRooms: boolean;
    public LocationGUID: string;
    public LocationName: string;
    public OrganizationGUID: string;
}
