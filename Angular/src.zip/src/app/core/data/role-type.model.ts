export class DataProviderRoleType {
    public id: string;          
    public seq: number;          
    public RoleTypeId: string;
    public Description: string; 
}