export class DataProviderAppUser {
    public id: string;          
    public seq: number;          
    public AppUserId: string;      
    public Name: string;
    public UserName: string;
    public Password: string;
}