export class DataProviderRentCar {
    public RentCarId: string;          
    public RentId: string;          
    public CarId: string;      
  
}