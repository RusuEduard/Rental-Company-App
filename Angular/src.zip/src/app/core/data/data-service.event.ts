export class DataServiceEvent {
    action: string;
}
