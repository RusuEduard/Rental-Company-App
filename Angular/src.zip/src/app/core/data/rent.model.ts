export class DataProviderRent {
    public RentId: string;          
    public AppUserId: string;          
    public CarAgencyId: string;      
    public DateFrom: Date;
    public DateTo: Date;
    public RentStatus: number;
}