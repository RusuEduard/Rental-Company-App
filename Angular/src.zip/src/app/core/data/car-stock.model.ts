export class DataProviderCarStock {
    public id: string;          
    public seq: number;          
    public CarStockId: string;      
    public CarId: string;       
    public CarAgencyId: string;     
    public ValidFrom: Date;      
    public ValidTo: Date;   
    public StockAmount: number;   
}