import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ProgressServiceFactory } from '../core/data/progress-service-factory';
import { getRentCarConfig } from '../core/data/rent-car.config';
import { DataProviderRentCar } from '../core/data/rent-car.model';
import { DataStateChangeEvent, GridComponent } from '@progress/kendo-angular-grid';
import { DataProviderRent } from '../core/data/rent.model';
import { getRentConfig } from '../core/data/rent.config';
import { DataProviderCar } from '../core/data/car.model';
import { getCarConfig } from '../core/data/car.config';

const createFormGroup: (item: any) => FormGroup = (dataItem: any) =>
  new FormGroup({
    RentCarId: new FormControl(dataItem.RentCarId),
    RentId: new FormControl(dataItem.RentId, Validators.required),
    CarId: new FormControl(dataItem.CarId, Validators.required)
    
  });

  
@Component({
  selector: 'app-rent-car-view',
  templateUrl: './rent-car-view.component.html',
  styleUrls: ['./rent-car-view.component.css']
})
export class RentCarViewComponent implements OnChanges {
  @Input() RentId: string = "";
  //public currentRentCar: string = "";
  public state: any = {
    skip: 0,
    take: 10,
    filter: {
      logic: 'and',
      filters: [],
    },
  };

  public state2: any = {
    skip: 0,
    take: 100,
  };

  public CarList: Array<DataProviderCar> =[];

  public editDataItem: DataProviderRentCar;
  public isNew: boolean;
  public dataService;
  public dataServiceData: any;
  public view;
  public editDataModel: any;
  public stateDataService;
  private editedRowIndex: number;
  private originalItem: any;
  public formGroup: FormGroup;
  public mySelection: any[];


  constructor(private progressServiceFactory: ProgressServiceFactory) {
    this.dataService =
    this.progressServiceFactory.getService<DataProviderRentCar>(
      getRentCarConfig(),
      this.state
    );
    
    this.view = this.dataService.dataChanges();
    this.stateDataService =
      this.progressServiceFactory.getService<DataProviderCar>(
        getCarConfig(),
        this.state2
      );
   }

  ngOnInit(): void {
    this.dataServiceData = this.dataService.dataChanges();
    this.dataService.dataChanges().subscribe((data) => {
    });
    if(this.RentId != ""){
      this.state.filter.filters = [{field: "RentId", operator: "eq", value: this.RentId}];
    }
    this.stateDataService.dataChanges().subscribe((data) => {
      if (data && data['data']) this.CarList = data['data'];
    });
    this.dataService.read(this.state);
    this.stateDataService.read();
    console.log("id",this.RentId);
  }
  ngOnChanges(): void{
    if(this.RentId != ""){
      this.state.filter.filters = [{field: "RentId", operator: "eq", value: this.RentId}];
    }
    this.dataService.read(this.state);
    console.log("id",this.RentId);
  }
  
  private readData(): void{
    console.log("In read data");
    this.dataServiceData = this.dataService.dataChanges();
    this.dataService.dataChanges().subscribe((data) => {
      if (data && data['data']) {
          console.log(data);
          this.RentId = data['data'][0]['RentId'];
          this.mySelection = [this.RentId];
      }
    });
    this.dataService.read();
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.dataService.read(this.state);
    this.mySelection=[state.skip];
  }

  public addHandler(e: any): void {
    console.log("add", e);
    const { sender } = e;
    this.editDataModel = this.dataService.createModel();
    this.formGroup = createFormGroup({});
    this.closeEditor(sender);
    sender.addRow(this.formGroup);
  }

  public editHandler( e: any ): void {
    
    const { sender, rowIndex, dataItem } = e;
    console.log(sender,rowIndex, dataItem);
    this.originalItem = Object.assign({}, dataItem);
    this.editDataModel = dataItem;
    this.formGroup = createFormGroup(this.originalItem);
    this.closeEditor(sender);
    this.editedRowIndex = rowIndex;
    sender.editRow(rowIndex, this.formGroup);
  }

  
  public cancelHandler({ sender, rowIndex }: any): void {
    Object.assign(this.editDataModel, this.originalItem);
    this.closeEditor(sender, rowIndex);
  }

  public saveHandler({ sender, rowIndex, isNew }: any): void {
    const item: any = Object.assign(this.editDataModel, this.formGroup.value);
    let cErrorMessage = "";

    if(cErrorMessage != "")
      alert(cErrorMessage);
      else{
      if (isNew) {
        this.dataService.create(item);
      } else {
        this.dataService.update(item);
      }
    
      sender.closeRow(rowIndex);
    }
  }
  public removeHandler(e: any): void {
    const { dataItem } = e;
    this.dataService.remove(dataItem);
  }

  gridUserSelectionChange(appuserGrid, selection) {
    console.log("mesa");
    const selectedData = selection.selectedRows[0].dataItem;
    this.RentId = selectedData.RentCarId;
    console.log("rent car",this.RentId);
  }

  private closeEditor(
    grid: GridComponent,
    rowIndex: number = this.editedRowIndex
  ): void {
    grid.closeRow(rowIndex);
    this.editedRowIndex = undefined;
  }

  public car(id: string):any{
    const t = this.CarList.find((x) => x.CarId === id);
    return t;
  }

}
