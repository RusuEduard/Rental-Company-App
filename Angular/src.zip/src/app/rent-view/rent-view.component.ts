import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { getRentConfig } from '../core/data/rent.config';
import { ProgressServiceFactory } from '../core/data/progress-service-factory';
import { DataStateChangeEvent, GridComponent } from '@progress/kendo-angular-grid';
import { DataProviderRent } from '../core/data/rent.model';
import { DataProviderAppUser } from '../core/data/app-user.model';
import { getAppUserConfig } from '../core/data/app-user.config';
const createFormGroup: (item: any) => FormGroup = (dataItem: any) =>
  new FormGroup({
    RentId: new FormControl(dataItem.RentId),
    AppUserId: new FormControl(dataItem.AppUserId),
    CarAgencyId: new FormControl(dataItem.CarAgencyId, Validators.required),
    DateFrom: new FormControl(dataItem.DateFrom, Validators.required),
    DateTo: new FormControl(dataItem.DateTo, Validators.required),
    RentStatus: new FormControl(dataItem.RentStatus, Validators.required),
  });
  
@Component({
  selector: 'app-rent-view',
  templateUrl: './rent-view.component.html',
  styleUrls: ['./rent-view.component.css']
})
export class RentViewComponent implements OnInit {
  public currentRent: string = "";

  public state: any = {
    skip: 0,
    take: 10,
    filter: {
      logic: 'and',
      filters: [],
    },
  };
  public state2: any = {
    skip: 0,
    take: 100,
  };
  public AppUserList: Array<DataProviderAppUser> =[];

  public editDataItem: DataProviderRent;
  public isNew: boolean;
  public dataService;
  public stateDataService;
  public dataServiceData: any;
  public view;
  public editDataModel: any;

  private editedRowIndex: number;
  private originalItem: any;
  public formGroup: FormGroup;
  public mySelection: any[];

  
  constructor(private progressServiceFactory: ProgressServiceFactory) {
    this.dataService =
      this.progressServiceFactory.getService<DataProviderRent>(
        getRentConfig(),
        this.state
      );

    this.view = this.dataService.dataChanges();
    this.stateDataService =
      this.progressServiceFactory.getService<DataProviderAppUser>(
        getAppUserConfig(),
        this.state2
      );
   }

  ngOnInit(): void {
    this.stateDataService.dataChanges().subscribe((data) => {
      if (data && data['data']) this.AppUserList = data['data'];
    });
    this.readData();
    this.stateDataService.read();
  }

  private readData(): void{
    console.log("In read data");
    this.dataServiceData = this.dataService.dataChanges();
    this.dataService.dataChanges().subscribe((data) => {
      if (data && data['data']) {
          this.currentRent = data['data'][0]['RentId'];
          this.mySelection = [this.currentRent];
      }
    });
    
    this.dataService.read();
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.dataService.read(this.state);
  }

  public addHandler(e: any): void {
    const { sender } = e;
    this.editDataModel = this.dataService.createModel();
    this.formGroup = createFormGroup({});
    this.closeEditor(sender);
    sender.addRow(this.formGroup);
  }

  public editHandler( e: any ): void {
    const { sender, rowIndex, dataItem } = e;
    this.originalItem = Object.assign({}, dataItem);
    this.editDataModel = dataItem;
    this.formGroup = createFormGroup(this.originalItem);
    this.closeEditor(sender);
    this.editedRowIndex = rowIndex;
    sender.editRow(rowIndex, this.formGroup);
  }

  public cancelHandler() {
    this.editDataItem = undefined;
  }

  public saveHandler({ sender, rowIndex, isNew }: any): void {
    const item: any = Object.assign(this.editDataModel, this.formGroup.value);
    let cErrorMessage = "";

    if(cErrorMessage != "")
      alert(cErrorMessage);
      else{
      if (isNew) {
        this.dataService.create(item);
      } else {
        this.dataService.update(item);
      }
    
      sender.closeRow(rowIndex);
    }
  }

  public removeHandler(e: any): void {
    const { dataItem } = e;
    this.dataService.remove(dataItem);
  }

  gridUserSelectionChange(rentGrid, selection) {
    const selectedData = selection.selectedRows[0].dataItem;
    this.currentRent = selectedData.RentId;
    console.log("mesaj2",this.currentRent);
  }

  private closeEditor(
    grid: GridComponent,
    rowIndex: number = this.editedRowIndex
  ): void {
    grid.closeRow(rowIndex);
    this.editedRowIndex = undefined;
  }

  public appuser(id: string): any {
    
    const t = this.AppUserList.find((x) => x.AppUserId === id);
    
    return t;
  }
}
