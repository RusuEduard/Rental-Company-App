import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppUserViewComponent } from './app-user-view/app-user-view.component';
import { CarStockViewComponent } from './car-stock-view/car-stock-view.component';
import { CarViewComponent } from './car-view/car-view.component';
import { RentCarViewComponent } from './rent-car-view/rent-car-view.component';
import { RentViewComponent } from './rent-view/rent-view.component';
import { RoleTypeViewComponent } from './role-type-view/role-type-view.component';

const routes: Routes = [
  {path:'car-view', component:CarViewComponent },
  {path:"car-stock-view", component:CarStockViewComponent},
  {path:"app-app-user-view", component:AppUserViewComponent},
  {path:"role-type-view", component:RoleTypeViewComponent},
  {path:"rent-view", component:RentViewComponent},
  {path:"rent-car-view", component:RentCarViewComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
